%% E-STOP CHECK
% A checking to roll through GUI inputs during an animation loop.
%
% [] = ECHECK()
% Outputs an error is the e-stop button on the GUI is pressed, cancelling all function and continuation of the simulation. 



function eCheck(EStopButtonPushed);

if EStopButtonPushed == 1
    display(['ABORTED']);
    error('The E-Stop button has been pushed and the system needs to be reset.');
end
end