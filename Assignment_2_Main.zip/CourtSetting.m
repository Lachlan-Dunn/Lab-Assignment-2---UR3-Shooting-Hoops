%% COURT SETTING

% Setting up the environment used to simululate the robot's demonstration.
% Outputs a large basketball court to scale with the UR3 centred in the
% middle.


function CourtSetting();

clf
doCameraSpin = false;
hold on;
workspace = [-4 4 -4 4 -4 4];  

% Find all graphic files
[f,v,data] = plyread('court2.ply','tri');
%Base
surf([-8,-8;8,8],[10,-10;10,-10],[0,0;0,0],'CData',imread('court_floor.jpg'),'FaceColor','texturemap');
%Base
surf([-3.5,-3.5;3.5,3.5],[6,-6;6,-6],[0,0;0,0],'CData',imread('b_court.jpg'),'FaceColor','texturemap');
%Front
surf([-8,8;-8,8],[10,10;10,10],[6,6;-1,-1],'CData',imread('b_crowd2.jpg'),'FaceColor','texturemap');
%Back
%surf([-2.125,2.125;-2.125,2.125],[-3.5,-3.5;-3.5,-3.5],[2,2;0,0],'CData',imread('b_crowd2.jpg'),'FaceColor','texturemap');
%Left
surf([8,8;8,8],[10,-10;10,-10],[6,6;-1,-1],'CData',imread('b_crowd.jpg'),'FaceColor','texturemap');
%Right
surf([-8,-8;-8,-8],[10,-10;10,-10],[6,6;-1,-1],'CData',imread('b_crowd.jpg'),'FaceColor','texturemap');


% Initialise and plot '.ply' file
vertexColours = [data.vertex.red, data.vertex.green, data.vertex.blue] / 255;
trisurf(f,v(:,1),v(:,2), v(:,3),'EdgeColor','interp','EdgeLighting','flat');

% Light for visability
camlight(0,0);

% Hold axis cubed
axis equal;

% Turn clipping off
ax = gca;
ax.Clipping = 'off';
% Allow camera movement
view(3);

hold off

end