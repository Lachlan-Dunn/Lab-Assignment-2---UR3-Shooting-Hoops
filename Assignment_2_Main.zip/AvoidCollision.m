%% AVOID COLLISION  
%Small asset used to detect and avoid collision by finding
% an optimal q1 position.
%
% [] = ADVOIDCOLLISION(ROBOT, FLAG, Q, FACES, VERTEX, FACENORMALS)
% Outputs an animation of initalisation where the robot is not brought down
% on top of an obstical. It will find the closest point to initalise from
% it's base q1 setting (0)rads. 
% 

function AvoidCollision(robot, flag, q, faces, vertex, faceNormals)
    iq = q;
    negcount = 0;
    poscount = 0;
    oq = zeros(1,6);

    while flag == true
    iq(1,1) = iq(1,1) - 0.05;
    q1 = jtraj(oq,iq,30);
    flag  = IsCollision(robot,q1,faces,vertex,faceNormals);
    negcount = negcount + 1;
    end
    nq = iq;

    flag = true;
    iq = q;

    while flag == true
    iq(1,1) = iq(1,1) + 0.05;
    q1 = jtraj(oq,iq,30);
    flag  = IsCollision(robot,q1,faces,vertex,faceNormals);
    poscount = poscount + 1;
    end
    pq = iq;

    if poscount <= negcount
        q = pq;
    else
        q = nq;
    end

    aniStepsUR3 = jtraj(oq,q,20);

    for i = 1:1:size(aniStepsUR3,1)
            robot.animate(aniStepsUR3(i,:));
            eCheck();
            pause(0.1);
 
    end 
end
