%% PROJECT_BLACK_MAMBA__ROBOTICS_41013
%
%MAIN SOURCE CODE
%DATE: 17/05/2021
%TEAM: Black Mamba
%MEMBERS: Lachlan Dunn 99143644, Edward Lind, Anthony Haplin 
%ROBOT: UR3
%FUNCTION DESCRIPTION: A UR3 model robot targets and shoots hoops.
%
%This source code found on the related respositry is the project of the AUT
%semester ROBOICS-41013 Class 2021. The project's aim is to use the UR3 to
%throw a projectile accuratly and at distance. There are stict limitations
%that came up early in the project. Such things include the physical
%limitations of joint velocities and set robotic functions (lspb) having
%their own limits for calculations and requirements when plotting catrisian
%pathways. 
%This code is used for the submission for Assignment 2 an is an assessed
%work under a period of time. 
%
% -------------------------------------------------------------------------------------------------------------------
close all
clear
clc
pendant = VirtualTeachPendant;



    %Slider Position Prompt
    count = 0;
    prompt = 'Select a value for the slider position. [-0.1 to 0.1]: ';
    while(1)
        type = input(prompt);
        if type > 0.1 | type < -0.1
            prompt ='Input was not valid. Try again. [-0.1 to 0.1]: ';
            count = count + 1;
                if count > 2
                    error('Too many incorrect inputs. Aborting initialisation.');
                end
        else type < 0.1 && type > -0.1
            display(['Setting hoop slider.']);
            slider = type - 0.1;
            break;
       
        end
    end
     
    %Obstical prompt
    count = 0;
    prompt = 'Do you wish to add obsticals? [Y/N]: ';
    while(1)
     type = input(prompt,'s');
        if type=='N' | type=='n'
            obsticalSetting = false;
            break;
        elseif type=='Y' | type=='y'
            display(['Adding a player to the court.']);
            obsticalSetting = true;
            break;
        else
            prompt = (['Input was not valid. Try again. [Y/N]: ']); 
            count = count + 1;
            if count > 2
                error('Too many incorrect inputs. Aborting sequence.');
            end
        end
    end
    
    %Point Initialisation
    steps = 30;
    qUR3 = zeros(1,6);
    qUR3O = qUR3;
    qUR3O(1,1) = pi;

    %Setting and Environment including UR3 Robot
    hold on
    CourtSetting();
    Hoop_ = LinearHoop(false);
    UR3_ = UR3;
    hold off
    
    %Fixing the view and eliminating clipping 
    view(3);
    ax = gca;
    ax.Clipping = 'off';

    %Initialisation of the obstical demonstration if chosen from the above
    %prompt
    if obsticalSetting == true;
        cp = [0.0,0.35,0.125];
        side = 0.25;
        UR3_O = UR3;
        UR3_O.model.base = transl(cp(1,1),cp(1,2),0)* rpy2tr(0,0,90 * pi/180);
        UR3_O.model.animate(qUR3O);
        plotOptions.plotFaces = false;
        plotOptions.plotEdges= false;
        [vertex,faces,faceNormals] = RectangularPrism(cp-side/2, cp+side/2,plotOptions);
    end

   
    %Initialising Q values for the UR3 to target
    newQUR3 = [0, 0.34906585, 2, 0, 1.57079, 0];
    newQUR3 = [0, 0.34906585, 2, (newQUR3(1,2)+ newQUR3(1,3)), 1.57079, 0];
    aniStepsUR3 = jtraj(qUR3,newQUR3,steps);
    %Detect if there are any collisions during the initialisation
    if obsticalSetting == true;
        CollisionFlag  = IsCollision(UR3_.model,aniStepsUR3,faces,vertex,faceNormals,'ask',true);
        if CollisionFlag == true;
            AvoidCollision(UR3_.model, CollisionFlag, newQUR3, faces, vertex, faceNormals);
        else
            for i = 1:1:size(aniStepsUR3,1)
               UR3_.model.animate(aniStepsUR3(i,:));
               pause(0.1);
               ES = pendant.read;
               eCheck(ES);
            end
        end
    else
    for i = 1:1:size(aniStepsUR3,1)
           UR3_.model.animate(aniStepsUR3(i,:));
           ES = pendant.read;
           eCheck(ES);
           pause(0.1);
    end
    end

    %Ball Setup and Display
    ballBag = RobotBall();
    ballBag.ball{1}.base = UR3_.model.fkine(newQUR3);
    animate(ballBag.ball{1},0);
    
    %BackBoard Initialisation and targeting
    qH1 = [slider];
    animate(Hoop_.model, qH1);
    bBoard = Hoop_.model.fkine(qH1)
    bBoard(3, 4) = bBoard(3, 4)+0.2417;
    bBoard = bBoard(1:3, 4);

    %Camera Setup
    cam = CentralCamera('focal', 0.08, 'pixel', 10e-5, 'resolution', [1024, 1024], ...
       'centre', [512, 512], 'name', 'effincam');

    %Find Target and plot ball curve
    display(['Initial Trajectory Estimation']);
    view(3);
    %Align the camera to the hoop to find coordinates
    [q,p] = Search(UR3_, ballBag, Hoop_, newQUR3, bBoard, cam);

    %Targeted co-ordinates and setting the angle of the throw
    target = p;
    angleTraj = 70;
    
    %Reset form to align for the shot
    newQUR3 = [q(1,1), 0.34906585, 2, 0, 1.57079, 0];
    newQUR3 = [newQUR3(1,1), 0.34906585, 2, (newQUR3(1,2)+ newQUR3(1,3)), 1.57079, 0];
    aniStepsUR3 = jtraj(q,newQUR3,steps);
    
    if obsticalSetting == true;
        CollisionFlag  = IsCollision(UR3_.model,aniStepsUR3,faces,vertex,faceNormals);
    end
    
    %Animate to default positoon after detecting hoop range
    for i = 1:1:size(aniStepsUR3,1)
       UR3_.model.animate(aniStepsUR3(i,:));
       ballBag.ball{1}.base = UR3_.model.fkine(aniStepsUR3(i,:));
       animate(ballBag.ball{1},0);
       camTc = UR3_.model.fkine(aniStepsUR3(i,:)');
       cam.T = camTc;  
       ES = pendant.read;
       eCheck(ES);
       drawnow;
       pause(0.1);
    end

    PlotTrajectory(UR3_, newQUR3, target, angleTraj,0);
    pause(1);
    oldQUR3 = newQUR3;

    %Adjust position and calculate trajectory again
    CollisionFlag = false;
    display(['Aligning UR3']);
    [newQUR3, xyUR3Angle, q1] = AdjustDirection(UR3_,cam, oldQUR3,target,ballBag, false);

    
    %Animation of the UR3 trying to leg over an obsticsal before attempting
    %to shoot
    if obsticalSetting == true;
      CollisionFlag  = IsCollision(UR3_.model,q1,faces,vertex,faceNormals);
        while CollisionFlag == true
        newQUR3(1,2) = newQUR3(1,2) - 0.05
        [newQUR3, xyUR3Angle, q1] = AdjustDirection(UR3_, cam, newQUR3,target,ballBag, false);
        CollisionFlag  = IsCollision(UR3_.model,q1,faces,vertex,faceNormals);
            if CollisionFlag == false
                aniStepsUR3 = jtraj(oldQUR3,newQUR3,20);

                 for i = 1:1:size(aniStepsUR3,1)
                            UR3_.model.animate(aniStepsUR3(i,:));
                            ballBag.ball{1}.base = UR3_.model.fkine(aniStepsUR3(i,:));
                            animate(ballBag.ball{1},0);
                            camTc = UR3_.model.fkine(aniStepsUR3(i,:)');
                            cam.T = camTc;
                            ES = pendant.read;
                            eCheck(ES);
                            drawnow;
                            pause(0.1);
                 end 
            end
        end
    end
 
    
    [newQUR3, xyUR3Angle, q1] = AdjustDirection(UR3_,cam, newQUR3,target,ballBag);
    [ballTrajectory,velocity] = PlotTrajectory(UR3_, newQUR3, target,angleTraj,0);

    %Steps used to simulate the velocity of the shot
    vSteps = 8;
    oldQUR3 = newQUR3;
    newQUR3 = [newQUR3(1,1), 0.69813, 2.09439, 2.7923, 1.57079, 0];
    aniStepsUR3 = jtraj(oldQUR3,newQUR3,steps);
    
    if obsticalSetting == true;
        CollisionFlag  = IsCollision(UR3_.model,aniStepsUR3,faces,vertex,faceNormals);
    end
     
    %Reering up to prepare for the shot animation
    for i = 1:1:size(aniStepsUR3,1)
            UR3_.model.animate(aniStepsUR3(i,:));
            ballBag.ball{1}.base = UR3_.model.fkine(aniStepsUR3(i,:));
            animate(ballBag.ball{1},0);
            camTc = UR3_.model.fkine(aniStepsUR3(i,:)');
            cam.T = camTc;
            ES = pendant.read;
            eCheck(ES)
            drawnow;
            pause(0.1);
    end 

     oldQUR3 = newQUR3;
     thisPoseUR3 = UR3_.model.fkine(oldQUR3);
     qT = [newQUR3(1,1), 0.52359, 0.9250, 0, 1.57079, 0];
     qT = [newQUR3(1,1), 0.52359, 0.9250, qT(1,2)+ qT(1,3) - deg2rad(angleTraj), 1.57079, 0];
     nextPoseUR3 = UR3_.model.fkine(qT);
     [ballTrajectory,velocity] = PlotTrajectory(UR3_, qT,target,angleTraj,1);

     [dis,vel,acc] = lspb(0,3,vSteps,velocity);
     aniStepsUR3 = ctraj(thisPoseUR3, nextPoseUR3, dis);    
     oldQUR3 = newQUR3;

     qMatrix = ikcon(UR3_.model, aniStepsUR3(:,:,1));
     for i = 2:1:size(aniStepsUR3,3)
       qs = ikcon(UR3_.model, aniStepsUR3(:,:,i));
       qMatrix = [qMatrix; qs];
     end 

    if obsticalSetting == true;
        CollisionFlag  = IsCollision(UR3_.model,qMatrix,faces,vertex,faceNormals);
    end

    for i = 1:1:size(aniStepsUR3,3)
    newQUR3 = ikcon(UR3_.model, aniStepsUR3(:,:,i), newQUR3);
    UR3_.model.animate(newQUR3);  
    ballBag.ball{1}.base = UR3_.model.fkine(newQUR3);
    animate(ballBag.ball{1},0);
    camTc = UR3_.model.fkine(newQUR3');
    cam.T = camTc;
    ES = pendant.read;
    eCheck(ES)
    drawnow;
    pause(0.1);
    display(['End effector Velocity is ' ,num2str(vel(i)),' m/s.']);
         if vel(i) >= velocity 
             endVel = vel(i);
             break;
         end
    end
         
     % Ball being thrown animation and bounce
    display(['Secondary Trajectory Estimation']);
    ThrowBall(ballBag, ballTrajectory);
    [bounce] = BallBounce(ballBag, 3);
    ThrowBall(ballBag, bounce);
    
    display(['SUMMARY']);
    
    bBoard(2,1) = bBoard(2,1) - 0.07;
    display(['The shot was dispatched and the results are:']);
    display(['The hoops location: ',num2str(bBoard')]);
    display(['The balls target: ',num2str(p)]);
    display(['The calculated velocity: ',num2str(velocity)]);
    display(['The end-effectors ending velocity: ',num2str(endVel)]);
    
    display(['Calculating Error... ']);
    err = norm(bBoard' - p);
    display(['The differnce in distance was ',num2str(err),'m']);
